# Training

## Monday
[Chest](muscle-groups/chest.md), [Triceps](muscle-groups/triceps.md), Shoulders

## Tuesday
Free

## Wednesday
Back, Biceps

## Thursday
Free

## Friday
Quads, Hamstrings, Glutes, Calves

## Saturday
Free

## Sunday
Free
